package com.wzz.exception;

public interface ErrorCode {

    int getCode();

    String getDesc();
}
