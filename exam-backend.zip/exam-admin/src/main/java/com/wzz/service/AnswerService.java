package com.wzz.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.wzz.entity.Answer;

/**
 * @author by wzz
 * @implNote 2020/10/20 9:04
 */
public interface AnswerService extends IService<Answer> {
}
